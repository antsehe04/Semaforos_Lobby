Ejercicio 2.4 PSP - Fernando, Manel, Antonio, Sergio
# Lobby:
Una sala de emparejamiento la cual tiene 10 ranuras donde los jugadores pueden esperar antes de entrar a una partida. También hay una única lobby que asigna jugadores a partidas uno por uno.

## Las reglas del sistema:

Habra jugadores que llegan

Si la partida tiene huecos libres, un jugador entra y muestra cuantos jugadores hay en la lobby

Si la lobby esta llena (10 jugadores), la partida empieza

Durante la partida, van a morir jugadores hasta que solo quede 1

Cuando gane, el juego le dejara solo 3 segundos, luego le echara de la partida.
